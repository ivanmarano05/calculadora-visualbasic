﻿Imports System.IO
Public Class frmCalculadora

    Dim num As String 'Acumula los números ingresados antes de presionar un signo
    Dim cadena As String 'Junta toda la operación para luego dividirla en partes y hacer la cuenta
    Dim parte1 As String 'Selecciona el primer número de la cadena
    Dim parte2 As String 'Selecciona el segundo número de la cadena
    Dim num1 As Double 'Convierte el primer número de string a double
    Dim num2 As Double 'Convierte el segundo número de string a double
    Dim posicionMas As String 'Guarda la posición del "+" en la cadena
    Dim posicionMenos As String 'Guarda la posición del "-" en la cadena
    Dim posicionPor As String 'Guarda la posición del "x" en la cadena
    Dim posicionDiv As String 'Guarda la posición del "/" en la cadena
    Dim primerNumero As Boolean 'Chequea si el número es el primero en ser ingresado
    Dim parteSinBorrarCadena As String 'Guarda la cadena cuando se borre el último número/signo
    Dim nombreArchivo As String 'Define el nombre del archivo a guardar
    Dim ubicacionArchivo As String 'Define la ubicación del archivo a guardar
    Dim archivo As String 'Concatena la ubicación del archivo con su nombre

    Private Sub frmCalculadora_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        'Se inicializan todas las variables vacias y se ocultan algunos labels externos
        Me.txtDatos.Text = ""
        Me.lblOperacion.Text = ""
        Me.lblOperacion.Visible = False
        Me.lblResultado.Text = ""
        Me.lblResultado.Visible = False
        Me.lblAux.Text = "" 'Label auxiliar para manejar los saltos de linea en txtDatos
        Me.lblAux.Visible = False
        Me.lblMostrar.Text = ""
        Me.lblCadena.Text = ""
        'Me.lblCadena.Visible = False
        num = ""
        Me.btnBorrar.Enabled = False 'Se bloquea el botón "Borrar" hasta que se ingrese un número
        primerNumero = True 'Se inicializa en True. Al momento de ingresar el primer número, pasa a False

        'Se indican el nombre y la ubicación del archivo, que luego serán concatenados en la variable "archivo"
        nombreArchivo = "Registro.txt"
        ubicacionArchivo = "C:\Users\ivanm\OneDrive\Escritorio\UCES Materias\14 - Programación GUI II\Ejercicios\Calculadora\"
        archivo = ubicacionArchivo + nombreArchivo

        Me.lblCadena.Select() 'Se selecciona este label para que la tecla "Enter" no afecte el rendimiento del teclado numérico

        'Se intentará leer el archivo del registro. Si este existe, se lee y a Aux se le asignan los datos del registro
        'Si no existe, se crea un nuevo .txt
        If File.Exists(archivo) Then
            Me.leer()
            Me.lblAux.Text = Me.txtDatos.Text
        Else
            Me.crear()
        End If

    End Sub

    'Clicks en los botones numéricos
    Private Sub btn1_Click(sender As Object, e As EventArgs) Handles btn1.Click
        pulsarNumero("1")
    End Sub

    Private Sub btn2_Click(sender As Object, e As EventArgs) Handles btn2.Click
        pulsarNumero("2")
    End Sub

    Private Sub btn3_Click(sender As Object, e As EventArgs) Handles btn3.Click
        pulsarNumero("3")
    End Sub

    Private Sub btn4_Click(sender As Object, e As EventArgs) Handles btn4.Click
        pulsarNumero("4")
    End Sub

    Private Sub btn5_Click(sender As Object, e As EventArgs) Handles btn5.Click
        pulsarNumero("5")
    End Sub

    Private Sub btn6_Click(sender As Object, e As EventArgs) Handles btn6.Click
        pulsarNumero("6")
    End Sub

    Private Sub btn7_Click(sender As Object, e As EventArgs) Handles btn7.Click
        pulsarNumero("7")
    End Sub

    Private Sub btn8_Click(sender As Object, e As EventArgs) Handles btn8.Click
        pulsarNumero("8")
    End Sub

    Private Sub btn9_Click(sender As Object, e As EventArgs) Handles btn9.Click
        pulsarNumero("9")
    End Sub

    Private Sub btn0_Click(sender As Object, e As EventArgs) Handles btn0.Click
        pulsarNumero("0")
    End Sub

    'Clicks en los botones de signos
    Private Sub btnSuma_Click(sender As Object, e As EventArgs) Handles btnSuma.Click
        pulsarSigno("+")
        hayDobleSigno("+")
        posicionMas = lblCadena.Text.IndexOf("+") '"posicionMas" guardará la posición de su signo
    End Sub

    Private Sub btnResta_Click(sender As Object, e As EventArgs) Handles btnResta.Click
        pulsarSigno("-")
        hayDobleSigno("-")
        posicionMenos = lblCadena.Text.IndexOf("-") '"posicionMenos" guardará la posición de su signo
    End Sub

    Private Sub btnMultiplicacion_Click(sender As Object, e As EventArgs) Handles btnMultiplicacion.Click
        pulsarSigno("x")
        hayDobleSigno("x")
        posicionPor = lblCadena.Text.IndexOf("x") '"posicionPor" guardará la posición de su signo
    End Sub

    Private Sub btnDivision_Click(sender As Object, e As EventArgs) Handles btnDivision.Click
        pulsarSigno("/")
        hayDobleSigno("/")
        posicionDiv = lblCadena.Text.IndexOf("/") '"posicionDiv" guardará la posición de su signo
    End Sub

    Private Sub btnPunto_Click(sender As Object, e As EventArgs) Handles btnPunto.Click
        pulsarNumero(".") 'El punto se manejará como un número más para no alterar el código
        cadena = decimales(cadena) 'Maneja la cadena en caso que se ingrese un 0
        Me.lblCadena.Text = cadena
    End Sub

    Private Sub btnIgual_Click(sender As Object, e As EventArgs) Handles btnIgual.Click
        pulsarSigno("=")
        hacerCuenta()
    End Sub

    Sub pulsarNumero(numero As String)

        'En caso de que sea el primer número ingresado, se fijará si el .txt está vacio. En caso de estarlo, se guarda
        'el número ingresado. Si no está vacio, se realiza el salto de linea y se ingresa el número.
        'Si no es el primer número ingresado, directamente se realiza el salto de linea y se ingresa el número.
        If primerNumero = True Then
            cadena = cadena + numero
            num = num + numero
            Me.lblOperacion.Text = num
            Me.lblCadena.Text = cadena

            If txtDatos.Text <> "" Then
                Me.txtDatos.SelectionStart = 0
                Me.txtDatos.Text = num + Chr(13) + Chr(10) + Me.lblAux.Text
            Else
                Me.lblAux.Text = num
                Me.txtDatos.Text = Me.txtDatos.Text + numero
            End If
        Else
            cadena = cadena + numero
            num = num + numero
            Me.lblOperacion.Text = num
            Me.lblCadena.Text = cadena
            Me.txtDatos.SelectionStart = 0
            Me.txtDatos.Text = num + Chr(13) + Chr(10) + Me.lblAux.Text
        End If

        Me.lblMostrar.Text = num
        Me.grabar() 'Los números se guardan automáticamente luego de su ingreso

        'En caso que el botón "Borrar" esté inhabilitado, se habilitará luego de ingresarse un número
        If Me.btnBorrar.Enabled = False Then
            Me.btnBorrar.Enabled = True
        End If

    End Sub

    Sub pulsarSigno(signo As String)

        primerNumero = False 'Setea la variable "primerNumero" en False ya que antes de un signo, siempre se ingresará
        'un número
        cadena = cadena + signo
        Me.lblAux.Text = Me.txtDatos.Text
        Me.txtDatos.SelectionStart = 0
        Me.txtDatos.Text = signo + Chr(13) + Chr(10) + Me.lblAux.Text
        Me.lblAux.Text = Me.txtDatos.Text
        Me.lblCadena.Text = cadena
        Me.lblOperacion.Text = signo
        Me.lblMostrar.Text = Me.lblMostrar.Text + signo
        num = ""
        Me.grabar() 'Los signos se guardan automáticamente luego de su ingreso
    End Sub

    'Chequea si existe un doble signo. En caso de existir, realiza la cuenta con el signo anterior al último ingresado
    'y guarda el resultado, el cual será tomado como "parte1" para el siguiente cálculo
    Sub hayDobleSigno(signo As String)
        Dim signos As Integer
        Dim I As Integer

        If Len(lblCadena.Text) > 0 Then
            For I = 1 To Len(lblCadena.Text)
                Select Case lblCadena.Text(I - 1)
                    Case = "+", "-", "x", "/"
                        signos = signos + 1
                        Select Case signos
                            Case > 1
                                hacerCuenta()
                                cadena = cadena + signo
                                lblCadena.Text = cadena
                        End Select
                End Select
            Next
        End If
    End Sub

    'Realiza la cuenta según el signo que encuentre. Se separa en partes, se pasa a double, se analiza el resultado y
    'finalmente se guarda en el registro
    Sub hacerCuenta()

        Select Case posicionMas
            Case > -1
                parte1 = Mid(lblCadena.Text, 1, posicionMas)
                parte2 = Mid(lblCadena.Text, posicionMas + 2, Len(Me.lblCadena.Text) - posicionMas - 2)
                num1 = Val(parte1)
                num2 = Val(parte2)
                lblResultado.Text = num1 + num2
                lblResultado.Text = convertirComa(lblResultado)
                lblResultado.Text = cantidadDecimales(lblResultado.Text)
                lblCadena.Text = lblResultado.Text
                cadena = lblResultado.Text
                posicionMas = ""
                Me.txtDatos.SelectionStart = 0
                Me.txtDatos.Text = lblResultado.Text + Chr(13) + Chr(10) + Me.lblAux.Text
                Me.lblAux.Text = Me.txtDatos.Text
                Me.lblMostrar.Text = lblResultado.Text
        End Select

        Select Case posicionMenos
            Case > -1
                parte1 = Mid(lblCadena.Text, 1, posicionMenos)
                parte2 = Mid(lblCadena.Text, posicionMenos + 2, Len(Me.lblCadena.Text) - posicionMenos - 2)
                num1 = Val(parte1)
                num2 = Val(parte2)
                lblResultado.Text = num1 - num2
                lblResultado.Text = convertirComa(lblResultado)
                lblResultado.Text = cantidadDecimales(lblResultado.Text)
                lblCadena.Text = lblResultado.Text
                cadena = lblResultado.Text
                posicionMenos = ""
                Me.txtDatos.SelectionStart = 0
                Me.txtDatos.Text = lblResultado.Text + Chr(13) + Chr(10) + Me.lblAux.Text
                Me.lblAux.Text = Me.txtDatos.Text
                Me.lblMostrar.Text = lblResultado.Text
        End Select

        Select Case posicionPor
            Case > -1
                parte1 = Mid(lblCadena.Text, 1, posicionPor)
                parte2 = Mid(lblCadena.Text, posicionPor + 2, Len(Me.lblCadena.Text) - posicionPor - 2)
                num1 = Val(parte1)
                num2 = Val(parte2)
                lblResultado.Text = num1 * num2
                lblResultado.Text = convertirComa(lblResultado)
                lblResultado.Text = cantidadDecimales(lblResultado.Text)
                lblCadena.Text = lblResultado.Text
                cadena = lblResultado.Text
                posicionPor = ""
                Me.txtDatos.SelectionStart = 0
                Me.txtDatos.Text = lblResultado.Text + Chr(13) + Chr(10) + Me.lblAux.Text
                Me.lblAux.Text = Me.txtDatos.Text
                Me.lblMostrar.Text = lblResultado.Text
        End Select

        Select Case posicionDiv
            Case > -1
                parte1 = Mid(lblCadena.Text, 1, posicionDiv)
                parte2 = Mid(lblCadena.Text, posicionDiv + 2, Len(Me.lblCadena.Text) - posicionDiv - 2)
                num1 = Val(parte1)
                num2 = Val(parte2)

                If num2 = 0 Then
                    MsgBox("No se puede dividir por 0")
                    btnLimpiar.PerformClick()
                    Exit Sub
                End If

                lblResultado.Text = num1 / num2
                lblResultado.Text = convertirComa(lblResultado)
                lblResultado.Text = cantidadDecimales(lblResultado.Text)
                lblCadena.Text = lblResultado.Text
                cadena = lblResultado.Text
                posicionDiv = ""
                Me.txtDatos.SelectionStart = 0
                Me.txtDatos.Text = lblResultado.Text + Chr(13) + Chr(10) + Me.lblAux.Text
                Me.lblAux.Text = Me.txtDatos.Text
                Me.lblMostrar.Text = lblResultado.Text
        End Select

        Me.grabar() 'Los resultados se guardan automáticamente luego de ser calculados

    End Sub

    'Limpia la mayoria de botones y labels y escribe la palabra "Limpiar" en el registro
    Private Sub btnLimpiar_Click(sender As Object, e As EventArgs) Handles btnLimpiar.Click
        cadena = ""
        parte1 = ""
        parte2 = ""
        Me.lblOperacion.Text = ""
        Me.lblCadena.Text = ""
        Me.lblResultado.Text = ""
        Me.lblMostrar.Text = ""
        posicionMas = ""
        posicionMenos = ""
        posicionPor = ""
        posicionDiv = ""
        primerNumero = True
        Me.txtDatos.SelectionStart = 0
        Me.txtDatos.Text = "Limpiar" + Chr(13) + Chr(10) + Me.lblAux.Text
        Me.lblAux.Text = Me.txtDatos.Text
        Me.lblCadena.Select()
        Me.grabar() 'Las limpiezas se guardan automáticamente luego de ser ejecutadas
        btnBorrar.Enabled = False
    End Sub

    'Borra el último número/signo ingresado y escribe "<--" en el registro
    Private Sub btnBorrar_Click(sender As Object, e As EventArgs) Handles btnBorrar.Click

        parteSinBorrarCadena = Mid(cadena, 1, Len(cadena) - 1)

        'En caso de borrar un signo, las posiciones de los mismos se vacian para no alterar el código
        Select Case cadena(Len(cadena) - 1)
            Case = "+", "-", "x", "/"
                posicionMas = ""
                posicionMenos = ""
                posicionPor = ""
                posicionDiv = ""
        End Select

        Me.lblMostrar.Text = parteSinBorrarCadena
        cadena = parteSinBorrarCadena
        num = ""
        Me.lblCadena.Text = cadena
        Me.txtDatos.SelectionStart = 0
        Me.txtDatos.Text = "<--" + Chr(13) + Chr(10) + Me.lblAux.Text
        Me.lblAux.Text = Me.txtDatos.Text
        Me.grabar() 'Los borrados se guardan automáticamente luego de ser ejecutados

        'Si la cadena termina vacia, el boton "Borrar" se inhabilitará hasta que se ingrese otro número
        If Me.lblCadena.Text = "" Then
            btnBorrar.Enabled = False
        End If
    End Sub

    'Funciones que crean, graban o leen el registro en un .txt
    Sub crear()
        Dim crearArchivo As FileStream = File.Create(archivo)
        crearArchivo.Close()
    End Sub

    Sub grabar()
        Dim grabarArchivo As New StreamWriter(archivo)
        grabarArchivo.Write(txtDatos.Text)
        grabarArchivo.Close()
    End Sub

    Sub leer()
        Dim leerArchivo As New StreamReader(archivo)
        Me.txtDatos.Text = leerArchivo.ReadToEnd
        leerArchivo.Close()
    End Sub

    'Función que llama a los botones desde el teclado numérico
    Protected Overrides Function ProcessCmdKey(ByRef msg As Message, ByVal keyData As Keys) As Boolean
        Select Case keyData
            Case Keys.NumPad1
                btn1.PerformClick()
            Case Keys.NumPad2
                btn2.PerformClick()
            Case Keys.NumPad3
                btn3.PerformClick()
            Case Keys.NumPad4
                btn4.PerformClick()
            Case Keys.NumPad5
                btn5.PerformClick()
            Case Keys.NumPad6
                btn6.PerformClick()
            Case Keys.NumPad7
                btn7.PerformClick()
            Case Keys.NumPad8
                btn8.PerformClick()
            Case Keys.NumPad9
                btn9.PerformClick()
            Case Keys.NumPad0
                btn0.PerformClick()
            Case Keys.Add
                btnSuma.PerformClick()
            Case Keys.Subtract
                btnResta.PerformClick()
            Case Keys.Multiply
                btnMultiplicacion.PerformClick()
            Case Keys.Divide
                btnDivision.PerformClick()
            Case Keys.Enter
                btnIgual.PerformClick()
            Case Keys.Decimal, Keys.Oemcomma
                btnPunto.PerformClick()
            Case Keys.Back
                btnBorrar.PerformClick()
            Case Keys.Control + Keys.Back
                btnLimpiar.PerformClick()
            Case Keys.Escape
                cerrarCalculadora()
        End Select
        Return MyBase.ProcessCmdKey(msg, keyData)
    End Function

    'Funciones que manejan el cierre de la calculadora luego de apretar la X de cierre o de presionar "Esc"
    Private Sub frmCalculadora_FormClosing(sender As Object, e As FormClosingEventArgs) Handles MyBase.FormClosing
        Dim opcion As Integer
        opcion = MsgBox("¿Desea cerrar la calculadora?", vbYesNo, "Atención")
        If opcion = vbYes Then
            End
        Else
            e.Cancel = True
        End If
    End Sub

    Sub cerrarCalculadora()
        Dim opcion As Integer
        opcion = MsgBox("¿Desea cerrar la calculadora?", vbYesNo, "Atención")
        If opcion = vbYes Then
            End
        End If
    End Sub
End Class
