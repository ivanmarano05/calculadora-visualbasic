﻿Module Validacion
    Public Function decimales(lblCadena As String) As String

        'Maneja si el primer caracter ingresado es un "." o un 0
        Dim parteSin0 As String
        Dim posicion0 As String

        posicion0 = lblCadena.IndexOf(0)


        Select Case Len(lblCadena)
            Case > 0
                Select Case lblCadena(0)
                    Case = "0"
                        Select Case Len(lblCadena)
                            Case > 1
                                Select Case lblCadena(1)
                                    Case = "."
                                        Exit Select
                                    Case <> "."
                                        parteSin0 = Mid(lblCadena, posicion0 + 2, Len(lblCadena) - posicion0 + 1)
                                        lblCadena = parteSin0
                                        Exit Select
                                End Select
                        End Select
                    Case = "."
                        lblCadena = "0."
                        Exit Select
                End Select
        End Select

        'If Len(lblCadena) > 0 Then
        '    If lblCadena(0) = "0" Then
        '        If Len(lblCadena) > 1 Then
        '            If lblCadena(1) <> "." Then
        '                parteSin0 = Mid(lblCadena, posicion0 + 2, Len(lblCadena) - posicion0 + 1)
        '                lblCadena = parteSin0
        '            End If
        '        End If
        '    ElseIf lblCadena(0) = "." Then
        '        lblCadena = "0."
        '    End If
        'End If

        'Si se encuentra un segundo punto, el mismo será ignorado
        'Dim parteSinPunto As String
        'Dim puntos As Integer

        'parteSinPunto = ""
        'puntos = 0

        'For I = 1 To Len(lblCadena)
        '    Select Case lblCadena(I - 1)
        '        Case = "."
        '            puntos = puntos + 1
        '            Select Case puntos
        '                Case > 1
        '                    parteSinPunto = Mid(lblCadena, 1, Len(lblCadena) - 1)
        '                    lblCadena = parteSinPunto
        '            End Select
        '    End Select
        'Next

        Return lblCadena
    End Function

    'Si el número recibido tiene muchos decimales, el mismo será recortado a 2 decimales
    Public Function cantidadDecimales(lblCadena As String) As String
        Dim parteConDosDecimales As String
        Dim posicionPunto As String

        posicionPunto = lblCadena.IndexOf(".")

        For I = 1 To Len(lblCadena)
            Select Case lblCadena(I - 1)
                Case = "."
                    parteConDosDecimales = Mid(lblCadena, 1, posicionPunto + 3)
                    lblCadena = parteConDosDecimales
                    'MsgBox(lblCadena)
                    Return lblCadena
            End Select
        Next

        Return lblCadena

    End Function

    'Convierte la "," del resultado de la cuenta en "." para realizar la operación sin problemas
    Public Function convertirComa(lblResultado As Label) As String
        Dim posicionComa As String
        Dim parte1 As String
        Dim parte2 As String

        posicionComa = lblResultado.Text.IndexOf(",")

        For I = 1 To Len(lblResultado.Text)
            Select Case lblResultado.Text(I - 1)
                Case = ","
                    parte1 = Mid(lblResultado.Text, 1, posicionComa)
                    parte2 = Mid(lblResultado.Text, posicionComa + 2, Len(lblResultado.Text) - posicionComa + 1)
                    lblResultado.Text = parte1 & "." & parte2
                    Exit For
            End Select
        Next

        Return lblResultado.Text
    End Function
End Module
