﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmCalculadora
    Inherits System.Windows.Forms.Form

    'Form reemplaza a Dispose para limpiar la lista de componentes.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Requerido por el Diseñador de Windows Forms
    Private components As System.ComponentModel.IContainer

    'NOTA: el Diseñador de Windows Forms necesita el siguiente procedimiento
    'Se puede modificar usando el Diseñador de Windows Forms.  
    'No lo modifique con el editor de código.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmCalculadora))
        Me.btn1 = New System.Windows.Forms.Button()
        Me.btn2 = New System.Windows.Forms.Button()
        Me.btn3 = New System.Windows.Forms.Button()
        Me.btnSuma = New System.Windows.Forms.Button()
        Me.btn4 = New System.Windows.Forms.Button()
        Me.btn5 = New System.Windows.Forms.Button()
        Me.btn6 = New System.Windows.Forms.Button()
        Me.btnResta = New System.Windows.Forms.Button()
        Me.btn7 = New System.Windows.Forms.Button()
        Me.btn8 = New System.Windows.Forms.Button()
        Me.btn9 = New System.Windows.Forms.Button()
        Me.btnMultiplicacion = New System.Windows.Forms.Button()
        Me.btnPunto = New System.Windows.Forms.Button()
        Me.btn0 = New System.Windows.Forms.Button()
        Me.btnBorrar = New System.Windows.Forms.Button()
        Me.btnDivision = New System.Windows.Forms.Button()
        Me.lblOperacion = New System.Windows.Forms.Label()
        Me.btnLimpiar = New System.Windows.Forms.Button()
        Me.btnIgual = New System.Windows.Forms.Button()
        Me.txtDatos = New System.Windows.Forms.TextBox()
        Me.lblResultado = New System.Windows.Forms.Label()
        Me.lblCadena = New System.Windows.Forms.Label()
        Me.lblAux = New System.Windows.Forms.Label()
        Me.lblMostrar = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btn1
        '
        Me.btn1.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.btn1.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn1.Font = New System.Drawing.Font("Verdana", 9.0!)
        Me.btn1.Location = New System.Drawing.Point(48, 80)
        Me.btn1.Name = "btn1"
        Me.btn1.Size = New System.Drawing.Size(52, 37)
        Me.btn1.TabIndex = 0
        Me.btn1.Text = "1"
        Me.btn1.UseVisualStyleBackColor = False
        '
        'btn2
        '
        Me.btn2.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.btn2.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn2.Font = New System.Drawing.Font("Verdana", 9.0!)
        Me.btn2.Location = New System.Drawing.Point(98, 80)
        Me.btn2.Name = "btn2"
        Me.btn2.Size = New System.Drawing.Size(52, 37)
        Me.btn2.TabIndex = 1
        Me.btn2.Text = "2"
        Me.btn2.UseVisualStyleBackColor = False
        '
        'btn3
        '
        Me.btn3.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.btn3.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn3.Font = New System.Drawing.Font("Verdana", 9.0!)
        Me.btn3.Location = New System.Drawing.Point(147, 80)
        Me.btn3.Name = "btn3"
        Me.btn3.Size = New System.Drawing.Size(52, 37)
        Me.btn3.TabIndex = 2
        Me.btn3.Text = "3"
        Me.btn3.UseVisualStyleBackColor = False
        '
        'btnSuma
        '
        Me.btnSuma.BackColor = System.Drawing.Color.Yellow
        Me.btnSuma.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnSuma.Font = New System.Drawing.Font("Verdana", 11.0!)
        Me.btnSuma.Location = New System.Drawing.Point(197, 80)
        Me.btnSuma.Name = "btnSuma"
        Me.btnSuma.Size = New System.Drawing.Size(52, 37)
        Me.btnSuma.TabIndex = 3
        Me.btnSuma.Text = "+"
        Me.btnSuma.UseVisualStyleBackColor = False
        '
        'btn4
        '
        Me.btn4.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.btn4.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn4.Font = New System.Drawing.Font("Verdana", 9.0!)
        Me.btn4.Location = New System.Drawing.Point(48, 115)
        Me.btn4.Name = "btn4"
        Me.btn4.Size = New System.Drawing.Size(52, 37)
        Me.btn4.TabIndex = 4
        Me.btn4.Text = "4"
        Me.btn4.UseVisualStyleBackColor = False
        '
        'btn5
        '
        Me.btn5.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.btn5.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn5.Font = New System.Drawing.Font("Verdana", 9.0!)
        Me.btn5.Location = New System.Drawing.Point(98, 115)
        Me.btn5.Name = "btn5"
        Me.btn5.Size = New System.Drawing.Size(52, 37)
        Me.btn5.TabIndex = 5
        Me.btn5.Text = "5"
        Me.btn5.UseVisualStyleBackColor = False
        '
        'btn6
        '
        Me.btn6.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.btn6.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn6.Font = New System.Drawing.Font("Verdana", 9.0!)
        Me.btn6.Location = New System.Drawing.Point(147, 115)
        Me.btn6.Name = "btn6"
        Me.btn6.Size = New System.Drawing.Size(52, 37)
        Me.btn6.TabIndex = 6
        Me.btn6.Text = "6"
        Me.btn6.UseVisualStyleBackColor = False
        '
        'btnResta
        '
        Me.btnResta.BackColor = System.Drawing.Color.Yellow
        Me.btnResta.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnResta.Font = New System.Drawing.Font("Verdana", 11.0!)
        Me.btnResta.Location = New System.Drawing.Point(197, 115)
        Me.btnResta.Name = "btnResta"
        Me.btnResta.Size = New System.Drawing.Size(52, 37)
        Me.btnResta.TabIndex = 7
        Me.btnResta.Text = "-"
        Me.btnResta.UseVisualStyleBackColor = False
        '
        'btn7
        '
        Me.btn7.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.btn7.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn7.Font = New System.Drawing.Font("Verdana", 9.0!)
        Me.btn7.Location = New System.Drawing.Point(48, 150)
        Me.btn7.Name = "btn7"
        Me.btn7.Size = New System.Drawing.Size(52, 37)
        Me.btn7.TabIndex = 8
        Me.btn7.Text = "7"
        Me.btn7.UseVisualStyleBackColor = False
        '
        'btn8
        '
        Me.btn8.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.btn8.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn8.Font = New System.Drawing.Font("Verdana", 9.0!)
        Me.btn8.Location = New System.Drawing.Point(98, 150)
        Me.btn8.Name = "btn8"
        Me.btn8.Size = New System.Drawing.Size(52, 37)
        Me.btn8.TabIndex = 9
        Me.btn8.Text = "8"
        Me.btn8.UseVisualStyleBackColor = False
        '
        'btn9
        '
        Me.btn9.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.btn9.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn9.Font = New System.Drawing.Font("Verdana", 9.0!)
        Me.btn9.Location = New System.Drawing.Point(147, 150)
        Me.btn9.Name = "btn9"
        Me.btn9.Size = New System.Drawing.Size(52, 37)
        Me.btn9.TabIndex = 10
        Me.btn9.Text = "9"
        Me.btn9.UseVisualStyleBackColor = False
        '
        'btnMultiplicacion
        '
        Me.btnMultiplicacion.BackColor = System.Drawing.Color.Yellow
        Me.btnMultiplicacion.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnMultiplicacion.Font = New System.Drawing.Font("Verdana", 11.0!)
        Me.btnMultiplicacion.Location = New System.Drawing.Point(197, 150)
        Me.btnMultiplicacion.Name = "btnMultiplicacion"
        Me.btnMultiplicacion.Size = New System.Drawing.Size(52, 37)
        Me.btnMultiplicacion.TabIndex = 11
        Me.btnMultiplicacion.Text = "x"
        Me.btnMultiplicacion.UseVisualStyleBackColor = False
        '
        'btnPunto
        '
        Me.btnPunto.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnPunto.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnPunto.Font = New System.Drawing.Font("Verdana", 15.0!)
        Me.btnPunto.Location = New System.Drawing.Point(48, 185)
        Me.btnPunto.Name = "btnPunto"
        Me.btnPunto.Size = New System.Drawing.Size(52, 37)
        Me.btnPunto.TabIndex = 12
        Me.btnPunto.Text = "."
        Me.btnPunto.TextAlign = System.Drawing.ContentAlignment.TopCenter
        Me.btnPunto.UseVisualStyleBackColor = False
        '
        'btn0
        '
        Me.btn0.BackColor = System.Drawing.SystemColors.ActiveBorder
        Me.btn0.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btn0.Font = New System.Drawing.Font("Verdana", 9.0!)
        Me.btn0.Location = New System.Drawing.Point(98, 185)
        Me.btn0.Name = "btn0"
        Me.btn0.Size = New System.Drawing.Size(52, 37)
        Me.btn0.TabIndex = 13
        Me.btn0.Text = "0"
        Me.btn0.UseVisualStyleBackColor = False
        '
        'btnBorrar
        '
        Me.btnBorrar.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnBorrar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnBorrar.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBorrar.Location = New System.Drawing.Point(147, 185)
        Me.btnBorrar.Name = "btnBorrar"
        Me.btnBorrar.Size = New System.Drawing.Size(52, 37)
        Me.btnBorrar.TabIndex = 14
        Me.btnBorrar.Text = "Borrar"
        Me.btnBorrar.UseVisualStyleBackColor = False
        '
        'btnDivision
        '
        Me.btnDivision.BackColor = System.Drawing.Color.Yellow
        Me.btnDivision.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnDivision.Font = New System.Drawing.Font("Verdana", 11.0!)
        Me.btnDivision.Location = New System.Drawing.Point(197, 185)
        Me.btnDivision.Name = "btnDivision"
        Me.btnDivision.Size = New System.Drawing.Size(52, 37)
        Me.btnDivision.TabIndex = 15
        Me.btnDivision.Text = "/"
        Me.btnDivision.UseVisualStyleBackColor = False
        '
        'lblOperacion
        '
        Me.lblOperacion.Location = New System.Drawing.Point(258, 9)
        Me.lblOperacion.Name = "lblOperacion"
        Me.lblOperacion.Size = New System.Drawing.Size(33, 22)
        Me.lblOperacion.TabIndex = 16
        Me.lblOperacion.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'btnLimpiar
        '
        Me.btnLimpiar.BackColor = System.Drawing.Color.FromArgb(CType(CType(128, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(255, Byte), Integer))
        Me.btnLimpiar.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnLimpiar.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnLimpiar.Location = New System.Drawing.Point(48, 220)
        Me.btnLimpiar.Name = "btnLimpiar"
        Me.btnLimpiar.Size = New System.Drawing.Size(151, 33)
        Me.btnLimpiar.TabIndex = 17
        Me.btnLimpiar.Text = "Limpiar"
        Me.btnLimpiar.UseVisualStyleBackColor = False
        '
        'btnIgual
        '
        Me.btnIgual.BackColor = System.Drawing.Color.Tomato
        Me.btnIgual.Cursor = System.Windows.Forms.Cursors.Hand
        Me.btnIgual.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.0!)
        Me.btnIgual.Location = New System.Drawing.Point(197, 220)
        Me.btnIgual.Name = "btnIgual"
        Me.btnIgual.Size = New System.Drawing.Size(52, 33)
        Me.btnIgual.TabIndex = 18
        Me.btnIgual.Text = "="
        Me.btnIgual.UseVisualStyleBackColor = False
        '
        'txtDatos
        '
        Me.txtDatos.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.txtDatos.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.txtDatos.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtDatos.Location = New System.Drawing.Point(51, 299)
        Me.txtDatos.Multiline = True
        Me.txtDatos.Name = "txtDatos"
        Me.txtDatos.ReadOnly = True
        Me.txtDatos.Size = New System.Drawing.Size(198, 73)
        Me.txtDatos.TabIndex = 19
        '
        'lblResultado
        '
        Me.lblResultado.Location = New System.Drawing.Point(99, 385)
        Me.lblResultado.Name = "lblResultado"
        Me.lblResultado.Size = New System.Drawing.Size(100, 23)
        Me.lblResultado.TabIndex = 20
        Me.lblResultado.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'lblCadena
        '
        Me.lblCadena.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.lblCadena.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblCadena.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblCadena.Location = New System.Drawing.Point(99, 262)
        Me.lblCadena.Name = "lblCadena"
        Me.lblCadena.Size = New System.Drawing.Size(100, 23)
        Me.lblCadena.TabIndex = 21
        Me.lblCadena.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblAux
        '
        Me.lblAux.Location = New System.Drawing.Point(255, 80)
        Me.lblAux.Name = "lblAux"
        Me.lblAux.Size = New System.Drawing.Size(47, 173)
        Me.lblAux.TabIndex = 23
        '
        'lblMostrar
        '
        Me.lblMostrar.BackColor = System.Drawing.SystemColors.ScrollBar
        Me.lblMostrar.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblMostrar.Font = New System.Drawing.Font("Verdana", 15.0!)
        Me.lblMostrar.Location = New System.Drawing.Point(51, 40)
        Me.lblMostrar.Name = "lblMostrar"
        Me.lblMostrar.Size = New System.Drawing.Size(198, 37)
        Me.lblMostrar.TabIndex = 24
        Me.lblMostrar.TextAlign = System.Drawing.ContentAlignment.MiddleRight
        '
        'frmCalculadora
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.GradientActiveCaption
        Me.ClientSize = New System.Drawing.Size(303, 404)
        Me.Controls.Add(Me.lblMostrar)
        Me.Controls.Add(Me.lblAux)
        Me.Controls.Add(Me.lblCadena)
        Me.Controls.Add(Me.lblResultado)
        Me.Controls.Add(Me.txtDatos)
        Me.Controls.Add(Me.btnIgual)
        Me.Controls.Add(Me.btnLimpiar)
        Me.Controls.Add(Me.lblOperacion)
        Me.Controls.Add(Me.btnDivision)
        Me.Controls.Add(Me.btnBorrar)
        Me.Controls.Add(Me.btn0)
        Me.Controls.Add(Me.btnPunto)
        Me.Controls.Add(Me.btnMultiplicacion)
        Me.Controls.Add(Me.btn9)
        Me.Controls.Add(Me.btn8)
        Me.Controls.Add(Me.btn7)
        Me.Controls.Add(Me.btnResta)
        Me.Controls.Add(Me.btn6)
        Me.Controls.Add(Me.btn5)
        Me.Controls.Add(Me.btn4)
        Me.Controls.Add(Me.btnSuma)
        Me.Controls.Add(Me.btn3)
        Me.Controls.Add(Me.btn2)
        Me.Controls.Add(Me.btn1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MaximumSize = New System.Drawing.Size(319, 443)
        Me.MinimumSize = New System.Drawing.Size(319, 443)
        Me.Name = "frmCalculadora"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Calculadora"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents btn1 As Button
    Friend WithEvents btn2 As Button
    Friend WithEvents btn3 As Button
    Friend WithEvents btnSuma As Button
    Friend WithEvents btn4 As Button
    Friend WithEvents btn5 As Button
    Friend WithEvents btn6 As Button
    Friend WithEvents btnResta As Button
    Friend WithEvents btn7 As Button
    Friend WithEvents btn8 As Button
    Friend WithEvents btn9 As Button
    Friend WithEvents btnMultiplicacion As Button
    Friend WithEvents btnPunto As Button
    Friend WithEvents btn0 As Button
    Friend WithEvents btnBorrar As Button
    Friend WithEvents btnDivision As Button
    Friend WithEvents lblOperacion As Label
    Friend WithEvents btnLimpiar As Button
    Friend WithEvents btnIgual As Button
    Friend WithEvents txtDatos As TextBox
    Friend WithEvents lblResultado As Label
    Friend WithEvents lblCadena As Label
    Friend WithEvents lblAux As Label
    Friend WithEvents lblMostrar As Label
End Class
